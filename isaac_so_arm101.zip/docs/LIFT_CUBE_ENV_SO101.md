# SO-101 Lift-Cube: среда, награды, таски и скрипты

Документ описывает **только Lift-Cube** для **SO-101** в расширении `isaac_so_arm101`

---

## 1. Архитектура конфигов


| Файл                              | Назначение                                                                                                                               |
| --------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| `tasks/lift/lift_env_cfg.py`      | Базовый **LiftEnvCfg**: сцена (стол, свет, камеры), команды, действия, **наблюдения**, **награды** по умолчанию, терминации, куррикулум. |
| `tasks/lift/joint_pos_env_cfg.py` | Конкретные таски SO-101: робот **SO_ARM101**, joint-position действия, куб, `ee_frame`, варианты **Dense / Sparse / Play**.              |
| `tasks/lift/guided_env_cfg.py`    | Варианты **Guided** (trajectory / discriminator) поверх joint-pos конфигов.                                                              |
| `tasks/lift/mdp/rewards.py`       | Реализации наград, в т.ч. trajectory / discriminator guidance.                                                                           |
| `tasks/lift/__init__.py`          | Регистрация Gym ID → `env_cfg_entry_point` + `rsl_rl_cfg_entry_point`.                                                                   |


При `gym.make("Isaac-…-v0")` Isaac Lab по строке `env_cfg_entry_point` **импортирует класс** конфига и строит `ManagerBasedRLEnv` по этому `cfg`.

---

## 2. Сцена и время

- **Робот**: SO-101 (`SO_ARM101_CFG`), articulation `…/Robot`.
- **Объект**: куб DexCube (Nucleus USD), начальная позиция задаётся в конфиге.
- **Стол / пол / свет**: `ObjectTableSceneCfg` в `lift_env_cfg.py`.
- **EE**: `FrameTransformer` от `base_link` к `gripper_link` с offset (конец эффектора для наград/наблюдений).
- **Симуляция**: `sim.dt = 0.01` (100 Гц физики), **`decimation = 2`** → шаг среды **20 Гц** (`0.02` с на шаг RL).
- **Эпизод**: `episode_length_s = 5.0` → при 20 Гц это **до 125 шагов** на эпизод (если нет раннего done).
- **Команда `object_pose`**: целевая поза для куба (Uniform pose command к `gripper_link`), ресэмплинг каждые **5 с**; диапазоны поз в `CommandsCfg` (`lift_env_cfg.py`).

---

## 3. Действия (actions)

Для SO-101 в `SoArm101LiftCubeEnvCfg`:

- **`arm_action`**: `JointPositionActionCfg` — суставы `shoulder_.*`, `elbow_flex`, `wrist_.*`, `scale=0.5`, `use_default_offset=True`.
- **`gripper_action`**: `BinaryJointPositionActionCfg` — сустав `gripper`, открыто/закрыто через выражения команд.

Размер вектора действий задаётся этими двумя компонентами действия.

---

## 4. Наблюдения (observations)

### 4.1. Группа `policy` (вектор состояния)

Все **компоненты** вектора наблюдения **склеиваются** в один тензор (`concatenate_terms = True`), при необходимости с **добавлением шума к наблюдениям** (в Isaac Lab — *observation corruption*), если `enable_corruption = True` (в Play часто отключают).


| Ключ (логически)         | Функция MDP                                         | Содержание                                       |
| ------------------------ | --------------------------------------------------- | ------------------------------------------------ |
| `joint_pos`              | `joint_pos_rel`                                     | Позиции суставов относительно дефолта робота.    |
| `joint_vel`              | `joint_vel_rel`                                     | Скорости суставов относительно дефолта.          |
| `object_position`        | `object_position_in_robot_root_frame`               | Позиция объекта в корневом фрейме робота (3D).   |
| `target_object_position` | `generated_commands` (`command_name="object_pose"`) | Команда цели (поза цели в пространстве команды). |
| `actions`                | `last_action`                                       | Предыдущее действие агента.                      |


Источники: `ObservationsCfg.PolicyCfg` в `lift_env_cfg.py`, часть функций — из `isaaclab.envs.mdp`, `object_position_in_robot_root_frame` — локально в `tasks/lift/mdp/observations.py`.

### 4.2. Группа `observation` (изображения)

Включена структура **`ImagesCfg`**: камеры `camera_top`, `camera_wrist` (Tiled RGB, 640×480). Для совместимости со скриптами есть **алиасы** `images_side` (= top) и `images_up` (= wrist).

**Важно для обучения без зрения:** при флаге **`disable_task_cameras = True`** в конфиге камеры **не спавнятся**, компоненты наблюдения с изображениями **обнуляются** (`lift_env_cfg.__post_init__`). В скриптах RSL-RL это делается через CLI **`--disable_task_cameras`**.

Чтобы получить RGB в рантайме, нужен запуск с **`--enable_cameras`** у `AppLauncher` / `isaaclab.sh`

---

## 5. Награды: общая форма

На каждом шаге среды Isaac Lab формирует **скалярную награду** как **сумму по компонентам награды**:

$$
R_t = \sum_i w_i \, r_{i,t}
$$

где $w_i$ — **вес** из `RewTerm(..., weight=...)`, $r_{i,t}$ — выход функции награды (часто уже в $[0,1]$ или штраф).

Ниже — **базовые** функции из `tasks/lift/mdp/rewards.py` (и стандартный MDP Isaac Lab для штрафов).

---

## 6. Dense Lift-Cube (`Isaac-SO-ARM101-Lift-Cube-v0`)

Базовый класс **`RewardsCfg`** в `lift_env_cfg.py` + SO-101 в `SoArm101LiftCubeEnvCfg`.

### 6.1. `reaching_object` — подвести EE к объекту

$$
r_{\text{reach}} = 1 - \tanh\left(\frac{\|p_{\text{obj}} - p_{\text{ee}}\|}{\sigma_{\text{reach}}}\right), \quad \sigma_{\text{reach}} = 0.05
$$

- $p_{\text{obj}}$, $p_{\text{ee}}$ — позиции объекта и EE (world), EE из `ee_frame`.
- **Вес** $w_{\text{reach}} = 1.0$.

### 6.2. `lifting_object` — поднять выше порога

$$
r_{\text{lift}} = \mathbb{1}\{ z_{\text{obj}} > h_{\min} \}, \quad h_{\min} = 0.025\,\text{м}
$$

- **Вес** $w_{\text{lift}} = 15.0$.

### 6.3. `object_goal_tracking` — грубое ведение к цели

Пусть $p_{\text{goal}}$ — целевая позиция команды `object_pose` в world (из команд робота и `des_pos_b`), $p_{\text{obj}}$ — позиция объекта.

$$
r_{\text{goal, coarse}} = \mathbb{1}\{ z_{\text{obj}} > h_{\min} \} \cdot \left(1 - \tanh\left(\frac{\|p_{\text{goal}} - p_{\text{obj}}\|}{\sigma_{\text{coarse}}}\right)\right)
$$

- $\sigma_{\text{coarse}} = 0.3$, $h_{\min} = 0.025$.
- **Вес** $16.0$.

### 6.4. `object_goal_tracking_fine_grained` — то же с мелким ядром

Та же формула, но $\sigma_{\text{fine}} = 0.05$, **вес** $5.0$.

### 6.5. `action_rate` и `joint_vel`

Стандартные компоненты награды в Isaac Lab:

- **`action_rate_l2`**: штраф за **изменение действий** между шагами (L2; знак минус через вес).
- **`joint_vel_l2`**: штраф за **скорости суставов** робота.

В Dense конфиге: **веса** $-10^{-4}$ каждый.

### 6.6. Куррикулум

В `CurriculumCfg` для компонентов `action_rate` и `joint_vel` вызывается **`modify_reward_weight`**: за **10000** шагов веса меняются к **$-0.1$** (более сильный штраф после разгона). Это влияет только на Dense вариант, где эти штрафы включены.



